# Aplikasi Pemesanan Cafe (DeCafe)
Sebuah aplikasi yang dapat dingunakan untuk pemesanan minuman dan makanan pada cafe, restoran, rumah makan atau yang sejenisnya.

## Pemilik/admin (1)
    -Melihat laporan
    -Menambah/mengubah/menghapus daftar menu dan harga
    -Menambah/mengubah/menghapus user
## Kasir (2)
    -Melihat harga dan total harga pesananan
    -Konfirmasi pembayaran
    -Membuat bukti pembayaran
## Pelayan (3)
    -Melihat menu dan harga
    -Memilih menu
    -Melihat total harga pesanan
    -Membuat pesanan
    -Update pesanan
    -Hapus pesanan
## Dapur (4)
    -Menerima pesanan
    -Konfirmasi terima pesanan
    -Mengubah status pesanan "siap saji"

## Pemilik/admin (1)
    -Daftar menu
    -Pesanan
    -User
    -Report
## Kasir (2)
    -Daftar menu
    -Pesanan
## Pelayan (3)
    -Daftar menu
    -Pesanan
## Dapur (4)
    -Pesanan